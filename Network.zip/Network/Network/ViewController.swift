//
//  ViewController.swift
//  Network
//
//  Created by student on 2018/12/17.
//  Copyright © 2018年 Young. All rights reserved.
//

import UIKit
import Alamofire

class ViewController: UIViewController {

    @IBOutlet weak var imageView1: UIImageView!
    @IBOutlet weak var imageView2: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    @IBAction func loadWithURL(_ sender: Any) {
        DispatchQueue.global().async {
            if let url = URL(string: "http://image.baidu.com/search/detail?z=0&ipn=d&word=虎太郎&step_word=&hs=0&pn=0&spn=0&di=0&pi=&tn=baiduimagedetail&is=0%2C0&istype=&ie=utf-8&oe=utf-8&cs=3651496942%2C2248248590&os=62285932%2C3189862800&simid=&adpicid=0&lpn=0&fm=&sme=&cg=&bdtype=0&simics=3697952879%2C2300155192&oriquery=&objurl=http%3A%2F%2Fb-ssl.duitang.com%2Fuploads%2Fitem%2F201804%2F23%2F20180423220302_zmgdo.thumb.700_0.jpg&fromurl=ippr_z2C%24qAzdH3FAzdH3Fooo_z%26e3B17tpwg2_z%26e3Bv54AzdH3Fks52AzdH3F%3Ft1%3Dl908clbn8&gsm=0&islist=&querylist=&cardserver=1") {
                if let data = try? Data(contentsOf: url) {
                    DispatchQueue.main.async {
                        self.imageView1.image = UIImage(data: data)
                    }
                }
            } else {
                print("图片获取失败！")
            }
        }
       
    }
    
    @IBAction func loadWithSession(_ sender: Any) {
        if let url = URL(string: "http://image.baidu.com/search/detail?z=0&ipn=d&word=虎太郎&step_word=&hs=0&pn=0&spn=0&di=0&pi=&tn=baiduimagedetail&is=0%2C0&istype=&ie=utf-8&oe=utf-8&cs=3651496942%2C2248248590&os=62285932%2C3189862800&simid=&adpicid=0&lpn=0&fm=&sme=&cg=&bdtype=0&simics=3697952879%2C2300155192&oriquery=&objurl=http%3A%2F%2Fb-ssl.duitang.com%2Fuploads%2Fitem%2F201804%2F23%2F20180423220302_zmgdo.thumb.700_0.jpg&fromurl=ippr_z2C%24qAzdH3FAzdH3Fooo_z%26e3B17tpwg2_z%26e3Bv54AzdH3Fks52AzdH3F%3Ft1%3Dl908clbn8&gsm=0&islist=&querylist=&cardserver=1") {
            //URLSession 会自动创建线程运行，闭包中的代码在另一个线程执行
            let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
                DispatchQueue.main.async {
                    self.imageView2.image = UIImage(data: data!)
                }
            }
            task.resume()
        }
    }
    @IBAction func loadwithAF(_ sender: Any) {
        if let url = URL(string: "http://image.baidu.com/search/detail?z=0&ipn=d&word=虎太郎&step_word=&hs=0&pn=0&spn=0&di=0&pi=&tn=baiduimagedetail&is=0%2C0&istype=&ie=utf-8&oe=utf-8&cs=3651496942%2C2248248590&os=62285932%2C3189862800&simid=&adpicid=0&lpn=0&fm=&sme=&cg=&bdtype=0&simics=3697952879%2C2300155192&oriquery=&objurl=http%3A%2F%2Fb-ssl.duitang.com%2Fuploads%2Fitem%2F201804%2F23%2F20180423220302_zmgdo.thumb.700_0.jpg&fromurl=ippr_z2C%24qAzdH3FAzdH3Fooo_z%26e3B17tpwg2_z%26e3Bv54AzdH3Fks52AzdH3F%3Ft1%3Dl908clbn8&gsm=0&islist=&querylist=&cardserver=1") {
            //向url网址发出请求，url地址响应Data文件回复，不用写在主线程中，AF回自己将其放入主线程中执行
            AF.request(url).responseData { (response) in
                self.imageView2.image = UIImage(data: response.data!)
            }
        }
    }
    
    
}

